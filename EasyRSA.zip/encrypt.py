from Crypto.Util.number import getPrime, inverse
flag = 'flag{a-z0-9}'
nbits = 2048
p = getPrime(nbits / 2)
q = getPrime(nbits / 2)
assert p != q
N = p * q
e = 0x10001
phiN = (p - 1) * (q - 1)
d = inverse(e, phiN)
phint = d % (p - 1)
qhint = q % (p - 1)


def str2int(s):
    return int(s.encode('hex'), 16)


with open('pubkey.txt', 'w') as f:
    f.write(str(e) + '\n')
    f.write(str(N) + '\n')
    f.write(str(phint) + '\n')
    f.write(str(qhint) + '\n')

plain = str2int(flag)

c = pow(plain, e, N)
with open('cipher.txt', 'w') as f:
    f.write(hex(c))
